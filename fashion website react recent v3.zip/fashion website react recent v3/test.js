function generateUniqueId() {
  const timestamp = new Date().getTime();
  const random = Math.floor(Math.random() * 10000);
  return `product${timestamp}${random}`;
}

const products = {
  button: [
    {
      id: generateUniqueId(),
      name: "pyjama button",
      image: 'img/button1.jpg'
    },
    // add more products as needed
  ],
  short: [
    {
      id: generateUniqueId(),
      name: "pyjama short satin",
      image: "img/satinShort2.jpg"
    },
    // add more products as needed
  ],
  underwear: [
    {
      id: generateUniqueId(),
      name: "Victoria",
      imageClosed: "img/victoriaClose.jpg",
      imageOpen: "img/victoriaOpen.jpg",
      isOpen: false,
      animationInterval: null
    },
    // add more products as needed
  ]
};

window.addEventListener("load", function () {
  const productCategories = Object.keys(products);

  productCategories.forEach((category) => {
    const productsList = products[category];

    productsList.forEach((product) => {
      if (category === "underwear") {
        const container = document.querySelector(`#${product.id}`);
        const closedImage = document.createElement("div");
        const openImage = document.createElement("div");

        closedImage.className = "closed-image";
        closedImage.style.backgroundImage = `url(${product.imageClosed})`;
        openImage.className = "open-image";
        openImage.style.backgroundImage = `url(${product.imageOpen})`;
        container.appendChild(closedImage);
        container.appendChild(openImage);

        container.addEventListener("mouseover", () => {
          product.isOpen = true;
          startAnimation(product);
        });

        container.addEventListener("mouseout", () => {
          product.isOpen = false;
          stopAnimation(product);
        });
      } else {
        const img = document.querySelector(`#${product.id}`);

        img.addEventListener("mouseover", handleImageHover);
        img.addEventListener("click", handleTouchStart);
        img.addEventListener("mouseout", handleImageOut);
      }
    });
  });
});

function startAnimation(product) {
  if (product.animationInterval === null) {
    product.animationInterval = setInterval(() => {
      const container = document.querySelector(`#${product.id}`);
      const closedImage = container.querySelector(".closed-image");
      const openImage = container.querySelector(".open-image");

      if (product.isOpen) {
        closedImage.style.transform = "rotateY(-180deg)";
        openImage.style.transform = "rotateY(0deg)";
      } else {
        closedImage.style.transform = "rotateY(0deg)";
        openImage.style.transform = "rotateY(180)"
      }
    }
    )
  }}